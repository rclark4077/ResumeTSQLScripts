use Resumes
go


INSERT INTO ProjectTypes
	(ProjectTypeDescription			, SortOrder)
SELECT
	'Miscellaneous'					, 1




